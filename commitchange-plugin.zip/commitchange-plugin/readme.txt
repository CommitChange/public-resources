=== CommitChange Plugin ===
Contributors: yutakahoulette
Tags: donation, nonprofit, widget
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The simplest way to embed CommitChange widgets into your WordPress site.

== Description ==

The simplest way to embed CommitChange widgets into your WordPress site.

== Installation ==

For a step-by-step installation and setup guide, please visit https://www.commitchange.com/pages/wp-plugin